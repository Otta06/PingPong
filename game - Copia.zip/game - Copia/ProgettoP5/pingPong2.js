let xBall1 = 20;
let yBall1 = 50;
let xSpeed1 = 5;
let ySpeed1 = 5;

let xBall2 =514;
let yBall2 = 50;
let xSpeed2 = 5;
let ySpeed2 = 5;
let sfondo;
let punti = 0;
let gameStopped = false;
let win;
let over;
function preload() {    
  sfondo = loadImage("./img/sfondo3.jpg");
  win = loadImage("./img/win1.jpg");
  over = loadImage("./img/gameOver.jpg");
}
function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background(sfondo);
  fill('white');
  rect(mouseX, 600, 90, 15);
  if(!gameStopped)
  {
    moveBall1();
    moveBall2();

    drawBall(xBall1, yBall1);
    drawBall(xBall2, yBall2);

    bounceBall1();
    bounceBall2();

    rac();
  }
  displayScore();

  if (punti === 10) {
    winScreen();
    gameStopped=true;
  }
  if ( yBall1 == 700) {
    overScreen();
    gameStopped=true;
  }
  if ( yBall2 == 700) {
    overScreen();
    gameStopped=true;
  }
}

function moveBall1() {
  xBall1 += xSpeed1;
  yBall1 += ySpeed1;
}
function moveBall2() {
  xBall2 += xSpeed2;
  yBall2 += ySpeed2;
}

function bounceBall1() {

  if (xBall1 < 0 || xBall1 > width - 10) {
    xSpeed1 *= -1;
  }
  if (yBall1 < 0 || yBall1 > height - 10) {
    ySpeed1 *= -1;
  }
}
function bounceBall2() {

  if (xBall2 < 0 || xBall2 > width - 15) {
    xSpeed2 *= -1;
  }
  if (yBall2 < 0 || yBall2 > height - 15) {
    ySpeed2 *= -1;
  }
}

function drawBall(x, y) {
  fill('green');
  ellipse(x, y, 20, 20);
}

function rac() {
  if ((xBall1 > mouseX && xBall1 < mouseX + 90) && (yBall1 + 10 >= 600)) {
    xSpeed1 *= -1;
    ySpeed1 *= -1;
    punti++;
  } else if ((xBall2 > mouseX && xBall2 < mouseX + 90) && (yBall2 + 10 >= 600)) {
    xSpeed2 *= -1;
    ySpeed2 *= -1;
    punti++;
  }
}

function displayScore() {
  fill('white');
  textSize(24);
  text("Punti: " + punti, 10, 25);
}


function winScreen() {
  background(win);
  fill('white');
  rect(700, 500, 100, 40);
  fill('green');
  textSize(16);
  text("HOME", 730, 525);
}
function overScreen() {
  background(over);
  fill('white');
  rect(700, 500, 100, 40);
  fill('green');
  textSize(16);
  text("HOME", 730, 525);
}
function mousePressed(){
  if (mousePressed && mouseX > 700 && mouseX < 800 && mouseY > 500 && mouseY<540){
    window.location.href = 'home.html';
  }
}