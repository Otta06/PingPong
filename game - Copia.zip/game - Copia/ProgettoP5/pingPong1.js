
let xBall = Math.floor(Math.random() * 300) + 50;
let yBall = 50;
let xSpeed = 5;
let ySpeed = 5;
let punti = 0
let sfondo;
let win;
let over;
let gameStopped = false; // Aggiunto un flag per controllare se il gioco è terminato
function preload() {    
  sfondo = loadImage("./img/sfondo1.png");
  win = loadImage("./img/win1.jpg");
  over = loadImage("./img/gameOver.jpg");
}
// Canvas
function setup() {
  createCanvas(windowWidth, windowHeight);
}

//Background

function draw() {

  // Background: bianco
  background(sfondo);

  // disegno la racchetta
  fill('black');
  rect(mouseX, 600, 90, 15);
  if(!gameStopped)
  {
    moveBall();
    drawBall();
    bounceBall();
    rac();
  }
  

  //punteggio
  fill('black');
  textSize(24);
  text("Punti: " + punti, 10, 25);
  //se il punteggio è uguale a 10 hai vinto
  if(punti==10)
  {
    winScreen();
    gameStopped = true; // Imposto il flag per fermare il gioco
  }
  //quando la pallina tocca per terra game over
  if ( yBall == 700) {
    overScreen();
    gameStopped=true;
  }
}
// faccio muovere la pallina
function moveBall() {
  xBall += xSpeed;
  yBall += ySpeed;
}

//quando la pallina arriva all'estremità rimbalza
function bounceBall() {

  if (xBall < 0 || xBall > width - 10) {
    xSpeed *= -1;
  }
  if (yBall < 0 || yBall > height - 10) {
    ySpeed *= -1;
  }
}

//disegno la pallina
function drawBall() {
  fill('blue');
  ellipse(xBall, yBall, 20, 20);
}

// quando la pallina colpisce la racchetta rimbalza
function rac() {
  if ((xBall > mouseX && xBall < mouseX + 90) && (yBall + 10 >= 600)) {
    xSpeed *= -1;
    ySpeed *= -1;
    punti++;

  }

}
function winScreen() {
  background(win);
  fill('white');
  rect(700, 500, 100, 40);
  fill('blue');
  textSize(16);
  text("HOME", 730, 525);
}
function overScreen() {
  background(over);
  fill('white');
  rect(700, 500, 100, 40);
  fill('blue');
  textSize(16);
  text("HOME", 730, 525);
}
function mousePressed(){
  if (mousePressed && mouseX > 700 && mouseX < 800 && mouseY > 500 && mouseY<540){
    window.location.href = 'home.html';
  }
}